package com.appeditmobile.reclaimcontrol.database;

import java.sql.Date;

public class BlockedApp {
    // Define fields for the BlockedApp table
    private String packageName;
    private int launchCount;
    private Date lastAccessedDate;

    // Constructor
    public BlockedApp(String packageName, int launchCount, Date lastAccessedDate) {
        this.packageName = packageName;
        this.launchCount = launchCount;
        this.lastAccessedDate = lastAccessedDate;
    }

    // Getters and setters for packageName, launchCount, and lastAccessedDate
    public String getPackageName() {
        return packageName;
    }

    public void setPackageName(String packageName) {
        this.packageName = packageName;
    }

    public int getLaunchCount() {
        return launchCount;
    }

    public void setLaunchCount(int launchCount) {
        this.launchCount = launchCount;
    }

    public Date getLastAccessedDate() {
        return lastAccessedDate;
    }

    public void setLastAccessedDate(Date lastAccessedDate) {
        this.lastAccessedDate = lastAccessedDate;
    }

    // Method to increment the launch count
    public void incrementLaunchCount() {
        launchCount++;
    }

    // Method to log all the data in the database
    public String toString() {
        return "BlockedApp [packageName=" + packageName + ", launchCount=" + launchCount + ", lastAccessedDate="
                + lastAccessedDate + "]";
    }
}
