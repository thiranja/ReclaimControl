package com.appeditmobile.reclaimcontrol;

import android.app.Activity;
import android.app.ActivityManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.CompoundButton;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.List;

public class AppListViewAdapter extends ArrayAdapter<ApplicationInfo> {

    private final Context mContext;
    private final Activity mActivity;
    private final PackageManager packageManager;
    private final LayoutInflater layoutInflater;

    public AppListViewAdapter(Context context, Activity activity, List<ApplicationInfo> apps) {
        super(context, 0, apps);
        mActivity = activity;
        mContext = context;
        packageManager = context.getPackageManager();
        layoutInflater = LayoutInflater.from(context);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null) {
            convertView = layoutInflater.inflate(R.layout.list_item_app, parent, false);
        }

        ApplicationInfo app = getItem(position);

        TextView textAppName = convertView.findViewById(R.id.text_app_name);
        textAppName.setText(app.loadLabel(packageManager));

        ToggleButton toggleLock = convertView.findViewById(R.id.toggle_lock);
        toggleLock.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

                if (isChecked) {
                    // Lock app
                    Log.d("Locked State","Locked");
                    ActivityManager am = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
                    List<ActivityManager.RunningTaskInfo> tasks = am.getRunningTasks(1);
                    if (!tasks.isEmpty()) {
                        ComponentName topActivity = tasks.get(0).topActivity;
                        if (!topActivity.getPackageName().equals(mContext.getPackageName())) {
                            am.moveTaskToFront(tasks.get(0).id, 0);
                        }
                    }
                } else {
                    // Unlock app
                    Log.d("Locked State","Unlocked");
//                    ActivityManager am = (ActivityManager) mContext.getSystemService(Context.ACTIVITY_SERVICE);
//                    am.moveTaskToBack(mContext.getTaskId());
                    mActivity.finishAndRemoveTask();
                }
            }
        });

        return convertView;
    }
}
