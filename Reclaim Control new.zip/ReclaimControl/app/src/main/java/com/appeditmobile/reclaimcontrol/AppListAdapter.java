package com.appeditmobile.reclaimcontrol;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.MyViewHolder> {

    private ArrayList<ApplicationInfo> appList;
    private ArrayList<ApplicationInfo> backuplist;
    private Context mContext;
    private PackageManager packageManager;

    private Activity parent;

    public AppListAdapter(Activity parent, PackageManager pm, ArrayList<ApplicationInfo> apps){
        this.parent = parent;
        this.appList = apps;
        packageManager = pm;
        backuplist = new ArrayList<>();
        backuplist.addAll(appList);
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // creating new view with the view holder
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.app_list_item,parent,false);

        ImageView appIcon = v.findViewById(R.id.app_icon_iv);
        TextView appName = v.findViewById(R.id.app_name_tv);
        ImageView warningIcon = v.findViewById(R.id.app_warning_icon);

        MyViewHolder vh = new MyViewHolder(v, appIcon, appName, warningIcon);
        return vh;
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        final ApplicationInfo appInfo = appList.get(position);
        holder.appIcon.setImageDrawable(packageManager.getApplicationIcon(appInfo));
        holder.appName.setText(packageManager.getApplicationLabel(appInfo));
        holder.warningIcon.setImageDrawable(packageManager.getApplicationIcon(appInfo));
//        holder.button.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                parent.startActivity(app.intent);
//            }
//        });

    }

    @Override
    public int getItemCount() {
        return this.appList.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        public ImageView appIcon;
        public TextView appName;
        public ImageView warningIcon;

        public MyViewHolder(@NonNull View itemView, ImageView appIcon, TextView appName, ImageView warningIcon) {
            super(itemView);
            this.appIcon = appIcon;
            this.appName = appName;
            this.warningIcon = warningIcon;
        }
    }

//    @Override
//    public View getView(int position, View convertView, ViewGroup parent) {
//        //return super.getView(position, convertView, parent);
//        // Getting the app in position
//        final ApplicationInfo appInfo = getItem(position);
//
//        ViewHolder viewHolder;
//
//        final View result;
//
//        if (convertView == null){
//            viewHolder = new ViewHolder();
//            LayoutInflater inflater = LayoutInflater.from(getContext());
//            convertView = inflater.inflate(R.layout.app_list_item,parent,false);
//            viewHolder.appIcon = convertView.findViewById(R.id.app_icon_iv);
//            viewHolder.appName = convertView.findViewById(R.id.app_name_tv);
//            viewHolder.warningIcon = convertView.findViewById(R.id.app_warning_icon);
//
//            result = convertView;
//            convertView.setTag(viewHolder);
//        }else{
//            viewHolder = (ViewHolder) convertView.getTag();
//            result = convertView;
//        }
//
//        // finally setting new values to the view
//        viewHolder.appIcon.setImageDrawable(packageManager.getApplicationIcon(appInfo));
//        viewHolder.appName.setText(packageManager.getApplicationLabel(appInfo));
//        viewHolder.warningIcon.setImageDrawable(packageManager.getApplicationIcon(appInfo));
//        viewHolder.warningIcon.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
////                Intent launchIntent = packageManager.getLaunchIntentForPackage(appInfo.packageName);
////                mContext.startActivity(launchIntent);
//                Toast.makeText(mContext, "Icon working", Toast.LENGTH_SHORT).show();
//            }
//        });
//
//        return convertView;
//    }

//    static class ViewHolder{
//        ImageView appIcon;
//        TextView appName;
//        ImageView warningIcon;
//    }

    // for the searching criteria
    void filter(String query){
        if (query == null){
            return;
        }
        query = query.toLowerCase(Locale.getDefault());

        appList.clear();
        if (query.length() == 0 ){
            // restore all the data
            appList.addAll(backuplist);
        }else{
            for (ApplicationInfo info : backuplist){
                if ( packageManager.getApplicationLabel(info)
                        .toString().toLowerCase(Locale.getDefault())
                        .contains(query)){

                    appList.add(info);
                }
            }
        }
        notifyDataSetChanged();
    }
}
