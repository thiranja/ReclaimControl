package com.appeditmobile.reclaimcontrol;

import static android.content.Context.WINDOW_SERVICE;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.PixelFormat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.appeditmobile.reclaimcontrol.database.BlockedApp;
import com.appeditmobile.reclaimcontrol.database.BlockedAppDatabaseHelper;

import java.sql.Date;
import java.text.SimpleDateFormat;

public class WarningWindow {

    private WindowManager wm;
    private WindowManager.LayoutParams params;
    private View myView;
    private String packageName;
    private Context mContext;
    private PackageManager pm;
    private BlockedAppDatabaseHelper dbHelper;
    private BlockedApp ba;
    private java.sql.Date sqlDate;
    boolean dateUpdateNeeded;

    WarningWindow(Context context, String packagename){
        mContext = context;
        packageName = packagename;
        pm = mContext.getPackageManager();
        dbHelper = new BlockedAppDatabaseHelper(mContext);
        ba = dbHelper.getBlockedApp(packageName);
        Date lastOpenDate = ba.getLastAccessedDate();

        // Get the current time in milliseconds
        long currentTimeMillis = System.currentTimeMillis();
        java.util.Date currentDate = new java.util.Date(currentTimeMillis);
        sqlDate = new java.sql.Date(currentDate.getTime());

        @SuppressLint("SimpleDateFormat") SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        String dateString1 = sdf.format(lastOpenDate);
        String dateString2 = sdf.format(sqlDate);

        if (dateString1.equals(dateString2)) {
            // date1 and date2 represent the same day
            dateUpdateNeeded = false;
        } else {
            // date1 and date2 represent different days
            ba.setLaunchCount(0);
            dateUpdateNeeded = true;
        }

        wm = (WindowManager) mContext.getSystemService(WINDOW_SERVICE);
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
        }else{
            params = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.TYPE_SYSTEM_ALERT,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
                    PixelFormat.TRANSLUCENT);
        }

        myView = LayoutInflater.from(mContext).inflate(R.layout.activity_warning, null);

        TextView usageText = myView.findViewById(R.id.warning_usage_text);
        usageText.setText("You have opened this app " + Integer.toString( ba.getLaunchCount()) + " times today");
        ImageView appIcon = myView.findViewById(R.id.warning_app_icon);
        try {
            appIcon.setImageDrawable(pm.getApplicationIcon(packageName));
        } catch (PackageManager.NameNotFoundException e) {
            e.printStackTrace();
        }
        Button exit = myView.findViewById(R.id.exit_button);
        exit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                navigateToHome();
                updateDatabase(false);
                wm.removeView(myView);

            }
        });
        Button open = myView.findViewById(R.id.proceed_button);
        open.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                launchApp();
                updateDatabase(true);
                wm.removeView(myView);
            }
        });
    }

    private void updateDatabase(boolean isOpening){
        if (isOpening){
            ba.incrementLaunchCount();
            if (dateUpdateNeeded){
                ba.setLastAccessedDate(sqlDate);
            }
        }else{
            if (dateUpdateNeeded) {
                ba.setLaunchCount(0);
            }
        }
        dbHelper.updateBlockedApp(ba);
    }

    public void showWindow(){
        wm.addView(myView,params);
    }

    private void launchApp(){
        Intent intent = pm.getLaunchIntentForPackage(packageName);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }

    private void navigateToHome() {
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        mContext.startActivity(intent);
    }
}
